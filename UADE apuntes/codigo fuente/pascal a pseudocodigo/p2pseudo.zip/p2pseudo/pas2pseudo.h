// -----------------------------------------------
// Conversor de Pascal a Pseudo Codigo
// -----------------------------------------------
// Por Kronoman
// En memoria de mi querido padre
// Copyright (c) 2003, Kronoman
// -----------------------------------------------

#ifndef PAS2PSEUDO_H
#define PAS2PSEUDO_H


// estructura contenedora de reemplazos
typedef struct TABLA_T
{
	char *org; // origen
	char *dst; // destino
} TABLA_T;

// Listado de reemplazos, todo en minusculas!
// Finalizar con NULL, NULL
TABLA_T tabla_pseudo[] =
  {
	{"program",""},
	{"input",""},
	{"output",""},
	{"input,output",""},
	{"var",""},
	{"integer",""},
	{"writeln", "mostrar" },
	{"readln", "ingresar"},
	{"if", "si"},
	{"then","entonces"},
	{"else","si no"},
	{"=", "es igual a"},
	{"begin",""},
	{"end",""},
	{"end.",""},
	{"case","caso"},
	{"of",""},
	{NULL,NULL} // fin de listado
  };
#endif