// -----------------------------------------------
// Conversor de Pascal a Pseudo Codigo
// -----------------------------------------------
// Por Kronoman
// En memoria de mi querido padre
// Copyright (c) 2003, Kronoman
// -----------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "pas2pseudo.h"


// -----------------------------------------------
// Funciones:
// -----------------------------------------------

// -----------------------------------------------
// Funciones portables para strupr, strlwr
// -----------------------------------------------
char *strupr(char *string)
{
      char *s;

      if (string)
      {
            for (s = string; *s; ++s)
                  *s = toupper(*s);
      }
      return string;
}
char *strlwr(char *string)
{
      char *s;

      if (string)
      {
            for (s = string; *s; ++s)
                  *s = tolower(*s);
      }
      return string;
}

// Saca los espacios al final de una cadena
char *rmtrail(char *str)
{
      int i;

      if (str && 0 != (i = strlen(str)))
      {
            while (--i >= 0)
            {
                  if (!isspace(str[i]))
                        break;
            }
            str[++i] = '\0';
      }
      return str;
}

// Saca los espacios al principio de una cadena
char *rmlead(char *str)
{
// Macro para mover la cadena, incluso con cadenas que se sobreponen
#define strMove(d,s) memmove(d,s,strlen(s)+1)

      char *obuf;

      if (str)
      {
            for (obuf = str; *obuf && isspace(*obuf); ++obuf)
                  ;
            if (str != obuf)
                  strMove(str, obuf);
      }
      return str;
}

// Sobreescribe los caracteres raros con espacios (o sea, los <= ASCII 13)
char *bajar_chars_raros(char *str)
{
char *s;

      if (str)
      {
            for (s = str; *s; ++s)
                  if (*s <= '\n') *s = ' '; // convertir a espacio
      }
      return str;
}


// -----------------------------------------------
// Procesa un comando individual, lo traduce al pseudo codigo
// y lo escribe en el archivo *fp, puede ser stdin
// -----------------------------------------------
void procesar_codigo(char *tkn, FILE *fp)
{
int i = 0, encontro = 0;
char *tmp;
// copiar, para no tocar el original y hacer chanchadas...
tmp = (char *)malloc(strlen(tkn) * sizeof(char));
if (tmp == NULL) return; // error! sin memoria?
strcpy(tmp, tkn);

strlwr(tmp); // pasar a minusculas

// chau espacios sobrantes
rmtrail(tmp);
rmlead(tmp);

// iterar tabla
for (i = 0; (tabla_pseudo[i].org != NULL) && (encontro==0); ++i)
{
if (strcmp(tabla_pseudo[i].org, tmp) == 0)
	{
	// encontro reemplazo, mostrar, y listo...
	fprintf(fp, "%s ", tabla_pseudo[i].dst);
	encontro = -1;
	}
}

if (!encontro) fprintf(fp, "%s ", tkn); // no encontro reemplazo, dejar el original

free(tmp);
}

// -----------------------------------------------
// Se fija si el caracter es un separador
// -1 = si, 0 = no
// -----------------------------------------------
int es_un_separador(char c)
{
char s[] = " ;():"; // separadores validos fuera de las strings (de instrucciones, solamente!)
int i = 0;
for (i=0; i < strlen(s); i ++ )
	if (s[i] == c) return -1;

return 0;
}

// -----------------------------------------------
// Toma una linea de codigo Pascal, y la separa en trozos
// Cada trozo es pasado a la funcion de traduccion... :^P
// Nota, el maximo del trozo es 255 chars...
// Pasarle el puntero al archivo a donde escribir la salida (puede ser stdin)
// -----------------------------------------------
void destroy_pascal_code(char *code, FILE *fp)
{
int i = 0 ; // contador
int string_c = 0; // contador de strings, para respetar las strings literales...
int comment_c = 0; // Contador de comentarios, para ignorarlos...
char tkn[256]; // token
int tkn_i = 0; // indice de escritura en token

for (i=0; i < strlen(code); i++)
	{
	// Ver si debo cortar la cadena
	if ( (string_c !=1) && (comment_c != 1) && es_un_separador(code[i]) )
	{
		tkn[tkn_i] = '\0';
			procesar_codigo(tkn, fp);
		tkn_i = 0;
	}
	else
	{
		// Ir armando el token
		if (comment_c == 0 )
		{
			tkn[tkn_i] = code[i];
			tkn_i++;
		}
	}

	// Ver si es una cadena, abrirla y cerrarla, de acuerdo al estado anterior
	if ( (code[i] == '\'')  && ( comment_c < 1) )
	{
		if (string_c == 1)
		{ string_c = 0;}
		else
		{ string_c = 1;}
	}

	// Ver si es un comentario, abrirlo y cerrarla, de acuerdo al estado anterior
	if ((code[i] == '{') && (string_c < 1)) comment_c ++ ;
	if ((code[i] == '}') && (string_c < 1)) comment_c -- ;

	}

// ultimo token
tkn[tkn_i] = '\0';
procesar_codigo(tkn, fp);
}



// -----------------------------------------------
// Entrada principal
// -----------------------------------------------
int main(int argc, char *argv[])
{
FILE *fpi = NULL, *fpo = NULL;
char buffer[256]; // buffer de lectura...

// Procesar archivos
printf("Pas2Pseudo\n\nCopyright (c) 2003, Kronoman\nEn memoria de mi querido padre\n");

if (argc < 3)
	{
	printf("Uso: \n%s entrada.pas salida.pas \n\n", argv[0]);
	return -1;
	}

// Abrir archivo de entrada
fpi = fopen(argv[1], "r");
if (fpi == NULL)
	{
	printf("Error abriendo : %s \n", argv[1] );
	return -1;
	}

// Abrir archivo de salida
fpo = fopen(argv[2], "w");
if (fpo == NULL)
	{
	printf("Error abriendo : %s \n", argv[2] );
	return -1;
	}

// Leer el archivo completo y procesarlo!
while (fgets (buffer , 256 , fpi) != NULL)
{
//        printf("%s\n", buffer);
	
	bajar_chars_raros(buffer); // sacarle caracteres raros

	destroy_pascal_code(buffer, fpo); // rock 'n roll!

	// saltar linea
	fprintf(fpo, "\n");
}


fclose(fpi);
fclose(fpo);
printf("Listo! %s --> %s \n", argv[1], argv[2]);
return 0;
}
