// Libreria para calcular una columna de la tabla de probabilidad binomial
// Por Alvaro Gonzalez Ferrer
// En memoria de mi querido padre
// Abril 2004

// ATENCION
// Formula usada:
//
// F(a) = Sumatoria (nCx)* p^x * (1-p)^(n-x)
//
// Esto genera F(a) ; para sacar G(a) usar G(r) = 1 - F(r-1)

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#include "binomial.h"

// Devuelve el factorial de un numero
int factorial(int num)
{
	int i;
	int ret = 1;
	
	for (i = num;i > 0; i--)  ret *= i;
	
	return ret;
}

// calcula la combinatoria , el [nCr] de la calculadora
int nCr(int n, int r)
{
	return factorial(n) / ( factorial(r) * factorial(n-r) );
}


// Calcula un solo valor de la probabilidad 
// ATENCION : recordar que hay que hacer sumatoria de los valores para obtener el valor real!
float calcular_prob_aux(int n, int r, float p)
{
	return (float)nCr(n,r) * pow(p,(float)r) * pow( ( 1.0-p), (float)(n-r) ) ;
}

// Devuelve una probabilidad de la tabla en si
// Pasarle n, r, p, devuelve el valor
// 
// Es: Fb(r/n, p) = [valor de devolucion]
//
float calcular_valor_prob(int n, int r, float p)
{
	int i;
	float ret  = 0.0;
	
	for (i=0; i < r+1; i++)
	{
		ret += calcular_prob_aux(n, i, p);
		if (ret > 1.0 ) return 1.0; // listo, llegamos a 1.0, se acabo la iteracion
	}
	

	return ret;
}

