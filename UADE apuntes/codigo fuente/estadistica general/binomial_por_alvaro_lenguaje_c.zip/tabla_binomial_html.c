// Genera una tabla binomial en HTML
// Por Alvaro Gonzalez Ferrer
// En memoria de mi querido padre
// Copyright (c) 2004
//
//
// ATENCION
// Formula usada:
//
// F(a) = Sumatoria (nCx)* p^x * (1-p)^(n-x)
//
// Esto genera F(a) ; para sacar G(a) usar G(r) = 1 - F(r-1)



#include <stdio.h>

#include "binomial.h"


int main(void)
{
// variables necesarias
FILE *fp;
	
// parametros para crear la tabla
int n_min = 3, n_max = 15; // n min / max
int r_max = 15; // va de 0 a r
float p_min = .0, p_max = 1.0, p_inc = .01;  // p min / max

int n, r, c=0; // c es un contador de color, para alternar colores de columnas
float p, valor;
	
printf(" Genera una tabla binomial en HTML\n");
printf(" Por Alvaro Gonzalez Ferrer\n");
printf(" En memoria de mi querido padre\n");
printf(" Copyright (c) 2004\n\n\n");
printf(" ATENCION\n");
printf(" Formula usada\n\n");
printf(" F(a) = Sumatoria (nCx)* p^x * (1-p)^(n-x)\n");
printf(" Esto genera F(a) ; para sacar G(a) usar G(r) = 1 - F(r-1)\n\n");
	
printf("Escribiendo archivo\n");
	
fp = fopen("tabla_binomial_alvaro.html", "w");	
if (fp == NULL) return -1; // error	
	
fprintf(fp,"<html>\n\t<head>\n\t\t<title>Tabla binomial por Alvaro Gonzalez Ferrer - Copyright (c) 2004</title>\n");


// estilo
fprintf(fp,"<style type=\"text/css\"><!--\ntd {\nfont-size: xx-small;\n\n}\n--></style>\n");

fprintf(fp, "\t</head>\n\n<body>\n");
fprintf(fp,"<h2>Tabla de probabilidades binomiales</h2><br><p>Por Alvaro Gonzalez Ferrer - Copright (c) 2004<br>En memoria de mi querido padre<br>Hecho en Argentina</p>\n");
fprintf(fp,"<p><b>NOTA: Esta tabla sirve para F(a) = Sumatoria (nCx) * p^x * (1-p)^(n-x), para sacar G(a) usar G(r) = 1 - F(r-1)</b></p><br><br>\n\n");

// estilos
#define ESTILO_P "style=\"background-color: #AAAAFF;\""
#define ESTILO_C1 "style=\"background-color: #EEEEEE;\""
#define ESTILO_C2 "style=\"background-color: #FFFFFF;\""

for (n = n_min; n < n_max+1; n++)
{
	
	printf("Escribiendo n = %3d de %3d\r", n, n_max); // feedback
	
	
	fprintf(fp,"<p><h3>n = %d </h3>\n<br>", n);
	
	fprintf(fp, "<table border=0>\n");
	// encabezado, poner 'p'
	fprintf(fp,"<tr><td %s><b>p/F(r)</b></td>", ESTILO_P);
	
	p = p_min;
	while (p < p_max)
	{
		fprintf(fp, "<td %s>%.2f </td>", ESTILO_P, p);
		p += p_inc;
	}
	fprintf(fp, "</tr>\n");

	// hacer la tabla
	for (r=0; r < r_max+1; r++)
	{
		fprintf(fp,"<tr><td %s><b>r%d </b></td>", (c%2) ? ESTILO_C1 : ESTILO_C2, r);
		// hacer fila
		p = p_min;
		while (p < p_max)
		{
			valor = calcular_valor_prob(n, r, p);
			
			fprintf(fp, "<td %s>%.3f</td>", (c%2) ? ESTILO_C1 : ESTILO_C2, valor);
			p += p_inc;
		}	
		// poner encabezado derecho inverso (para G)		
		fprintf(fp,"<td %s><b>r%d</b></td></tr>\n", (c%2) ? ESTILO_C1 : ESTILO_C2, r_max-r);
		c++;
	}
	
	
	
	// encabezado inverso (para que sirva para 'G' tambien
	fprintf(fp, "<tr><td>&nbsp;</td>");
	p = p_max;
	while (p > p_min)
	{
		fprintf(fp, "<td %s>%.2f</td>", ESTILO_P, p);
		p -= p_inc;
	}
	fprintf(fp,"<td %s><b>p/G(r)</td>", ESTILO_P);
	fprintf(fp, "</tr>\n");
	
	fprintf(fp,"</table><hr>\n");
	
}


fprintf(fp,"<br><hr><p>Tabla binomial por Alvaro Gonzalez Ferrer - Copyright (c) 2004</p>\n</body>\n</html>\n");

fclose(fp);
printf("Listo OK                     \n\n");	
return 0;
}
