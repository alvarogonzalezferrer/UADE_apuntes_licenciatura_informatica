// Libreria para calcular una columna de la tabla de probabilidad binomial
// Por Alvaro Gonzalez Ferrer
// En memoria de mi querido padre
// Abril 2004

// ATENCION
// Formula usada:
//
// F(a) = Sumatoria (nCx)* p^x * (1-p)^(n-x)
//
// Esto genera F(a) ; para sacar G(a) usar G(r) = 1 - F(r-1)

#ifndef BINOMIAL_H
#define BINOMIAL_H

int factorial(int num);
int nCr(int n, int r);
float calcular_prob_aux(int n, int r, float p);
float calcular_valor_prob(int n, int r, float p);

#endif

