// Calcula un item de la tabla binomial en HTML
// Por Alvaro Gonzalez Ferrer
// En memoria de mi querido padre
// Copyright (c) 2004
//
//
// ATENCION
// Formula usada:
//
// F(a) = Sumatoria (nCx)* p^x * (1-p)^(n-x)
//
// Esto genera F(a) ; para sacar G(a) usar G(r) = 1 - F(r-1)



#include <stdio.h>

#include "binomial.h"


int main(void)
{
int n,r;
float p;

printf(" Calcula la probabilidad binomial\n");
printf(" Por Alvaro Gonzalez Ferrer\n");
printf(" En memoria de mi querido padre\n");
printf(" Copyright (c) 2004\n\n\n");

printf("Calcula Fb(r/n,p) y Gb(r/n,p)\n\n");

printf("Ingrese r ? ");
scanf("%d", &r);

printf("Ingrese n ? ");
scanf("%d", &n);

printf("Ingrese p ? ");
scanf("%f", &p);

printf("Fb(%d/%d, %f) = %f\n", r,n,p, calcular_valor_prob(n, r, p));

if (r > 0) printf("Gb(%d/%d, %f) = %f\n\n", r,n,p, 1-calcular_valor_prob(n, r-1, p));



return 0;
}
